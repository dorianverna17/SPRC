import paho.mqtt.client as mqtt
import time
import sys

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe("sprc/chat/#")
    if sys.argv[1] == 'friend':
        client.subscribe("sprc/friend")
    if sys.argv[1] == 'dorian.verna':
        client.subscribe("sprc/dorian.verna")

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("broker.hivemq.com", 1883, 60)
client.loop_start()

time.sleep(1)
default_publish = "sprc/chat/" + sys.argv[1]
while True:
    msg = input()

    if msg == 'exit':
        break
    elif msg.startswith("friend:"):
        client.publish("sprc/" + "friend", msg)
    elif msg.startswith("dorian.verna:"):
        client.publish("sprc/" + "dorian.verna", msg)
    else:
        client.publish(default_publish, msg)

    time.sleep(1)

client.loop_stop()
